package com.kitchen.order;

public enum OrderStatus {
    CREATED, SHELVED, PICKED_UP, WASTED, DELIVERED
}
